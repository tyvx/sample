package org.openapitools.api;

import org.openapitools.model.InlineObject;
import org.openapitools.model.User;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Generated;

/**
 * A delegate to be called by the {@link UsersApiController}}.
 * Implement this interface with a {@link org.springframework.stereotype.Service} annotated class.
 */
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2022-04-03T17:52:15.553231400+09:00[Asia/Tokyo]")
public interface UsersApiDelegate {

    default Optional<NativeWebRequest> getRequest() {
        return Optional.empty();
    }

    /**
     * GET /users/{userId} : Get User Info by User ID
     * Retrieve the information of the user with the matching user ID.
     *
     * @param userId Id of an existing user. (required)
     * @return User Found (status code 200)
     *         or User Not Found (status code 404)
     * @see UsersApi#getUsersUserId
     */
    default ResponseEntity<User> getUsersUserId(Integer userId) {
        getRequest().ifPresent(request -> {
            for (MediaType mediaType: MediaType.parseMediaTypes(request.getHeader("Accept"))) {
                if (mediaType.isCompatibleWith(MediaType.valueOf("application/json"))) {
                    String exampleString = "{ \"firstName\" : \"firstName\", \"lastName\" : \"lastName\", \"emailVerified\" : true, \"dateOfBirth\" : \"1997-10-31T00:00:00.000+0000\", \"id\" : 0, \"email\" : \"email\", \"createDate\" : \"2000-01-23\" }";
                    ApiUtil.setExampleResponse(request, "application/json", exampleString);
                    break;
                }
            }
        });
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

    /**
     * PATCH /users/{userId} : Update User Information
     * Update the information of an existing user.
     *
     * @param userId Id of an existing user. (required)
     * @param body  (optional)
     * @return User Updated (status code 200)
     *         or User Not Found (status code 404)
     *         or Email Already Taken (status code 409)
     * @see UsersApi#patchUsersUserId
     */
    default ResponseEntity<User> patchUsersUserId(Integer userId,
        InlineObject body) {
        getRequest().ifPresent(request -> {
            for (MediaType mediaType: MediaType.parseMediaTypes(request.getHeader("Accept"))) {
                if (mediaType.isCompatibleWith(MediaType.valueOf("application/json"))) {
                    String exampleString = "{ \"firstName\" : \"firstName\", \"lastName\" : \"lastName\", \"emailVerified\" : true, \"dateOfBirth\" : \"1997-10-31T00:00:00.000+0000\", \"id\" : 0, \"email\" : \"email\", \"createDate\" : \"2000-01-23\" }";
                    ApiUtil.setExampleResponse(request, "application/json", exampleString);
                    break;
                }
            }
        });
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

}
