package com.example.demo.api;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.InlineObject;
import com.example.demo.model.User;
import com.example.demo.repository.UserMapper;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class UserApiImpl implements UserApi {

    @Resource
    private UserMapper userMapper;
	
	@Override
	public ResponseEntity<User> postUser(@Valid InlineObject body) {
		User user = new User();
		user.setDateOfBirth(body.getDateOfBirth());
		user.setEmail(body.getEmail());
		user.setFirstName(body.getFirstName());
		user.setLastName(body.getLastName());
		
		userMapper.insert(user);
	
		
		
		return new ResponseEntity<User>(user, HttpStatus.OK);
	}


}
