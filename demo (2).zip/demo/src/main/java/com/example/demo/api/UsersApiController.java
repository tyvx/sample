package com.example.demo.api;

import javax.annotation.Resource;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.User;
import com.example.demo.repository.UserMapper;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class UsersApiController implements UsersApi {
	

    @Resource
    private UserMapper userMapper;
    
    @Override
	public ResponseEntity<User> getUsersUserid(String userid) {
		User user;
		
		user = userMapper.select(Integer.parseInt(userid));
				
		return new ResponseEntity<User>(user, HttpStatus.OK);
	}

	
	
}
