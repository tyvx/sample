
CREATE TABLE IF NOT EXISTS t_user (
  id INT NOT NULL ,
  firstName TEXT NOT NULL,
  lastName TEXT NOT NULL,
  email TEXT NOT NULL,
  dateOfBirth DATE DEFAULT NULL,
  emailVerified INT NOT NULL ,
  createDate DATE DEFAULT NULL 
);
