--
-- openapi.v1.
-- Prepared SQL queries for 'inline_object_1' definition.
--


--
-- SELECT template for table `inline_object_1`
--
SELECT `firstName`, `lastName`, `email`, `dateOfBirth` FROM `inline_object_1` WHERE 1;

--
-- INSERT template for table `inline_object_1`
--
INSERT INTO `inline_object_1`(`firstName`, `lastName`, `email`, `dateOfBirth`) VALUES (?, ?, ?, ?);

--
-- UPDATE template for table `inline_object_1`
--
UPDATE `inline_object_1` SET `firstName` = ?, `lastName` = ?, `email` = ?, `dateOfBirth` = ? WHERE 1;

--
-- DELETE template for table `inline_object_1`
--
DELETE FROM `inline_object_1` WHERE 0;

