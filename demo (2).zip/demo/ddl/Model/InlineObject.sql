--
-- openapi.v1.
-- Prepared SQL queries for 'inline_object' definition.
--


--
-- SELECT template for table `inline_object`
--
SELECT `firstName`, `lastName`, `email`, `dateOfBirth` FROM `inline_object` WHERE 1;

--
-- INSERT template for table `inline_object`
--
INSERT INTO `inline_object`(`firstName`, `lastName`, `email`, `dateOfBirth`) VALUES (?, ?, ?, ?);

--
-- UPDATE template for table `inline_object`
--
UPDATE `inline_object` SET `firstName` = ?, `lastName` = ?, `email` = ?, `dateOfBirth` = ? WHERE 1;

--
-- DELETE template for table `inline_object`
--
DELETE FROM `inline_object` WHERE 0;

