--
-- openapi.v1.
-- Prepared SQL queries for 'User' definition.
--


--
-- SELECT template for table `User`
--
SELECT `id`, `firstName`, `lastName`, `email`, `dateOfBirth`, `emailVerified`, `createDate` FROM `User` WHERE 1;

--
-- INSERT template for table `User`
--
INSERT INTO `User`(`id`, `firstName`, `lastName`, `email`, `dateOfBirth`, `emailVerified`, `createDate`) VALUES (?, ?, ?, ?, ?, ?, ?);

--
-- UPDATE template for table `User`
--
UPDATE `User` SET `id` = ?, `firstName` = ?, `lastName` = ?, `email` = ?, `dateOfBirth` = ?, `emailVerified` = ?, `createDate` = ? WHERE 1;

--
-- DELETE template for table `User`
--
DELETE FROM `User` WHERE 0;

