/* SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO"; */
/* SET AUTOCOMMIT = 0; */
/* START TRANSACTION; */
/* SET time_zone = "+00:00"; */

-- --------------------------------------------------------

--
-- Table structure for table `inline_object` generated from model 'inlineUnderscoreobject'
--

CREATE TABLE IF NOT EXISTS `inline_object` (
  `firstName` TEXT DEFAULT NULL,
  `lastName` TEXT DEFAULT NULL,
  `email` TEXT DEFAULT NULL COMMENT 'If a new email is given, the user&#39;s email verified property will be set to false.',
  `dateOfBirth` TEXT DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Table structure for table `inline_object_1` generated from model 'inlineUnderscoreobjectUnderscore1'
--

CREATE TABLE IF NOT EXISTS `inline_object_1` (
  `firstName` TEXT NOT NULL,
  `lastName` TEXT NOT NULL,
  `email` TEXT NOT NULL,
  `dateOfBirth` DATE NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Table structure for table `User` generated from model 'User'
--

CREATE TABLE IF NOT EXISTS `User` (
  `id` INT NOT NULL COMMENT 'Unique identifier for the given user.',
  `firstName` TEXT NOT NULL,
  `lastName` TEXT NOT NULL,
  `email` TEXT NOT NULL,
  `dateOfBirth` DATE DEFAULT NULL,
  `emailVerified` TINYINT(1) NOT NULL COMMENT 'Set to true if the user&#39;s email has been verified.',
  `createDate` DATE DEFAULT NULL COMMENT 'The date that the user was created.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


